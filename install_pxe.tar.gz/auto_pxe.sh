#!/bin/bash
#----------------------------
#Author:Devil
#Version:2.0
#Address:879423371@qq.com
#slogan:心之所向,素履以往
#----------------------------
#PXE网络装机
#本脚本适用于192.168.4.200主机
#ks.cfg必须放在root下
#虚拟机必须提前加载CDROM(redhat7.4)
#请保证真机密码为Taren1 虚拟机密码为123456
#---------------------------
green='\033[32m'
plain='\033[0m'
red='\033[31m'
YUMCHECK=`yum repolist |awk '/repolist/ {print$2}' |sed 's/,//'`
#安装前的准备
function pre_install(){
if [ $YUMCHECK -ne 0 ];then
echo -e "#######${green}正在安装软件包,请耐心等待${plain}#########"
    install_rpm
else
   cd /etc/yum.repos.d/ && mkdir old_repo
   mv *.repo old_repo/
   echo -e "${red}未找到YUM源${plain}" && echo "正在准备YUM源，请等待"
   echo "[development]
name=rhel7.4
baseurl=ftp://192.168.4.254/rhel7
enabled=1
gpgcheck=0" >/etc/yum.repos.d/dvd.repo
yum clean all &>/dev/null
echo -e "#######${green}YUM 安装成功${plain}#########"
echo -e "#######${green}正在安装软件包,请耐心等待${plain}#########"
    install_rpm
fi
}
#装包
function install_rpm(){
yum -y install dhcp &>/dev/null
   echo -e "#######${green}dhcp 安装成功${plain}#########"
   yum -y install tftp-server &>/dev/null
   echo -e "#######${green}tftp-server 安装成功${plain}#########"
   yum -y install vsftpd &>/dev/null
   echo -e "#######${green}vsftpd 安装成功${plain}#########"
   yum -y install syslinux &>/dev/null
   echo -e "#######${green}syslinux 安装成功${plain}#########"
   yum -y install system-config-kickstart &>/dev/null
   echo -e "#######${green}system-config-kickstart 安装成功${plain}#########"
   yum -y install expect &>/dev/null
   echo -e "#######${green}expect 安装成功${plain}#########"
expect <<EOF
 spawn scp -p 192.168.4.254:/root/ks.cfg /root
 expect "yes" {send "yes\n"}
 expect "password" { send "Taren1\n"}
 expect "#" { send "exit\n"}
EOF
}
#配置dhcp
function config_dhcp(){
cd /etc/dhcp/
cp dhcpd.conf{,.bak}
echo "subnet 192.168.4.0 netmask 255.255.255.0 {
  range 192.168.4.101 192.168.4.199;
  option domain-name-servers 192.168.4.200;
  default-lease-time 600;
  max-lease-time 7200;
  next-server 192.168.4.200;
  filename "pxelinux.0" ;}" >>dhcpd.conf
  sed -i '12c filename "pxelinux.0"; }' dhcpd.conf
systemctl restart dhcpd
systemctl enable dhcpd &>/dev/null
}
#配置tftp
function config_tftp(){
cd /var/lib/tftpboot/ && mkdir pxelinux.cfg
cp /var/ftp/rhel7/isolinux/vesamenu.c32 .
cp /var/ftp/rhel7/isolinux/initrd.img .
cp /var/ftp/rhel7/isolinux/splash.png .
cp /var/ftp/rhel7/isolinux/vmlinuz .
cp /usr/share/syslinux/pxelinux.0 .
cp /var/ftp/rhel7/isolinux/isolinux.cfg pxelinux.cfg/default
chmod u+w pxelinux.cfg/default
sed -i '65,+100d' pxelinux.cfg/default
sed -i '62a menu default' pxelinux.cfg/default
sed -i '65c append initrd=initrd.img ks=ftp://192.168.4.200/ks.cfg' pxelinux.cfg/default
cp /root/ks.cfg /var/ftp
systemctl restart vsftpd
systemctl enable vsftpd &>/dev/null
systemctl restart tftp  
systemctl enable tftp  &>/dev/null
}
#配置ftp
function config_ftp(){
mkdir /var/ftp/rhel7
mount /dev/cdrom /var/ftp/rhel7
}
case $1 in
install)
         pre_install
         config_dhcp
         config_ftp
         config_tftp
         echo -e "#######${green}部署完毕,2秒后脚本自毁${plain}#########"
         sleep 2
         rm -rf /root/auto_pxe.sh;;
*)
         echo -e "${red}用法:$0 install${plain}";;
esac

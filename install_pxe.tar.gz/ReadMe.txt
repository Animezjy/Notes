PXE装机脚本:
	教学环境下，在真机解压，scp拷贝到虚拟机。  ./auto_pex.sh install即可。


Functions:
	install:            直接安装
	

Files：
 	auto_pxe.sh --> 主文件 
	ks.cfg 	--> 无人值守安装

ISSUE:
1、安装虚拟机ip为192.168.4.200
2、确保真机密码为Taren1虚拟机密码为123456!!!!!.
3、确保ks.cfg和auto_pxe.sh都在root下
4、虚拟机必须提前加载CDROM(本脚本使用的镜像为rhel7.4)

Versions:
1.0	基本功能完成.
1.1     增加了颜色提示，修复bug



